### Apuntes de Docker
- No guardan el estado, así que cuando se pare, se pierde todo.
- Proporciona dependencia de software.
- Son independientes y se pueden conectar entre sí por red
- Para guardar estado se necesita de conectar a un volumen externo.
- Se pueden crear imágenes personalizadas.
- Son 4 máquinas diferentes.