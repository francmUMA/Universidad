package com.example.todolist;

public enum Status {INCOMPLETA, COMPLETADA}
