package com.example.calculadora;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/")
public class CalculadoraApplication extends Application {

}