#!/bin/bash
# Creamos el archivo $1.xlsx -- $1 es la característica que queremos medir
touch "$1.xlsx"

