enable
conf t
spanning-tree mode rapid-pvst
exit
copy running-config startup-config

exit
