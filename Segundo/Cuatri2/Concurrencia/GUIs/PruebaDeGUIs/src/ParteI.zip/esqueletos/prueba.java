package esqueletos;

import java.util.Random;

public class prueba {
    public static void main(String[] args) {
        System.out.println(2.0 % 2);
    }
}
